# Bucket Cat

This is the landing page for the $BUCKET meme coin.